import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#bf1249',
        secondary: '#4a4a4a',
        hole_body: '#f0f0f0',
        swap: {
          DEFAULT: '#ccc',
          click_clr: '#bf1249',
          hover_clr: '#4a4a4a'
        }
      }
    },
  },
  plugins: [],
};
export default config;
