'use client'
import React, { useState } from 'react'
import Image from 'next/image'
import login_bg from '../../public/login/login-bg.jpg'
import logo from '../../public/login/loginlogo.svg'


const page = () => {
  const [tab, setTab] = useState(true)
  return (
    <section id='login' className='flex flex-col items-center justify-center h-screen w-full flex-1 px-20 text-center bg-hole_body'>
      <div className='w-2/3 max-w-4xl float-left'>
        <p className='float-left heading'>LOGIN</p>
      </div>
      <div className='bg-white shadow-2xl flex flex-row w-2/3 max-w-4xl'>
        <div className='relative w-3/6 bg-primary'>
          <Image src={login_bg} alt='login-bg' className='absolute inset-0 h-full w-full object-fit' />
          <div className='absolute inset-0 bg-primary bg-opacity-65 '></div>
          <div className='relative flex justify-center items-center w-full h-full flex-col'>
            <Image src={logo} width={100} height={100} alt='logo' />
            <p className='uppercase text-[10px] tracking-[3px] leading-relaxed text-white font-semibold raleway'>Reach | Global Communication Platform</p>
          </div>
        </div>
        <div className='w-3/6 p-5'>
          <div className='flex mb-2 border-b-[1px] border-b-swap w-full'>
            <p className='login_tab hover:login_hover login_click'>LOGIN</p>
            <p className='login_tab hover:login_hover'>REGISTER</p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default page