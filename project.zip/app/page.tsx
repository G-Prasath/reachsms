import React from 'react'
import Login from './Login/page'

const page = () => {
  return (
    <>
      <Login />
    </>
  )
}

export default page